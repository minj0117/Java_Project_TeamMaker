"use strict";

//모바일 토글 버튼
const toggleBtn = document.querySelector(".toggleBtn");
const uplog = document.querySelectorAll(".uplog");
const navbar_upper = document.querySelector(".navbar_upper");

toggleBtn.addEventListener("click", () => {
  console.log("토글 버튼 클릭");
  Array.from(uplog).forEach((element) => {
    element.classList.toggle("active");
  });
  navbar_upper.classList.toggle("active");
});

//신고하기
window.addEventListener("load", init);
function init() {
  let reportTag = document.querySelector("#report");

  reportTag.addEventListener("click", report_F);
}

function report_F(event) {
  event.preventDefault();
  console.log("report");
  const url = event.target.href;
  const fname = event.target.id;
  const top =
    document.getElementById("commPostView").getBoundingClientRect().top + 200;
  const left =
    document.getElementById("commPostView").getBoundingClientRect().left + 300;
  console.log(top, left);
  const option =
    "width=550, height=350, top=" +
    top +
    ", left=" +
    left +
    ", location=no, resizable=no";
  console.log(option);
  window.open(url, fname, option);
}

//댓글 moreBtn
const moreBtn = document.querySelector(".moreBtn");
const hiddenMenu = document.querySelector(".hiddenMenu");

moreBtn.addEventListener("click", () => {
  console.log("moreBtn 클릭");
  moreBtn.classList.toggle("active");
  hiddenMenu.classList.toggle("active");
});

//댓글 작성
//댓글 작성 상위 요소
const comment = decument.querySelector(".comment");

//댓글 작성 focus 이벤트 발생시 버튼 활성화
comment
  .querySelector(".writeComment")
  .addEventListener(
    "focus",
    (e) => (e.target.parentElement.style.display = "block")
  );

//댓글 작성 이벤트 등록
comment.addEventListener("click", (e) => {
  const writeComment = comment.querySelector(".writeComment");

  //댓글 입력 시
  writeComment.addEventListener("keyup", (e) => {
    console.log(e.target.textConent.trim().length);
  });
});
