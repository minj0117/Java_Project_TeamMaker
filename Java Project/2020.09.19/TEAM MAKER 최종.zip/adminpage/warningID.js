const wids = document.querySelectorAll(".wid");
const wreason = document.querySelector(".warningReason");

Array.from(wids).forEach((ids) => {
  ids.addEventListener("click", (e) => {
    e.target
      .closest(".warningList")
      .nextElementSibling.classList.toggle("active");
  });
});

// wid.addEventListener("click", (e) => {
//   console.log("아이디 클릭");

//   wreason.classList.toggle("active");
// });
