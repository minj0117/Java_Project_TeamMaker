"use strict";

const ids = document.querySelectorAll(".wid");
const wreason = document.querySelector(".warningReason");

Array.from(ids).forEach((wid) => {
  wid.addEventListener("click", (e) => {
    console.log("아이디 클릭");
    e.target
      .closest(".warningList")
      .nextElementSibling.classList.toggle("active");
  });
});
