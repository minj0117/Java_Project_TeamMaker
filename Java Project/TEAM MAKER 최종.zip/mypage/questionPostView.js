// 답변 부분 화살표 클릭 시
const moreBtn = document.querySelector(".moreBtn");
const answerPart = document.querySelector(".answerPart");

moreBtn.addEventListener("click", () => {
  console.log("moreBtn 클릭");
  moreBtn.classList.toggle("clicked");
  answerPart.classList.toggle("active");
});
