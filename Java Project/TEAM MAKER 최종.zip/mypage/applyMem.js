"use strict";

const toggleBtn = document.querySelector(".toggleBtn");
const uplog = document.querySelectorAll(".uplog");
const navbar_upper = document.querySelector(".navbar_upper");

toggleBtn.addEventListener("click", () => {
  console.log("토글 버튼 클릭");
  Array.from(uplog).forEach((element) => {
    element.classList.toggle("active");
  });
  navbar_upper.classList.toggle("active");
});

//프로필 보기
window.addEventListener("load", init);
function init() {
  let profileTag = document.querySelector("#profile");

  profileTag.addEventListener("click", profile_F);
}

function profile_F(event) {
  event.preventDefault();
  console.log("report");
  const url = event.target.href;
  const fname = event.target.id;
  const top =
    document.getElementById("makeTeamPostView").getBoundingClientRect().top +
    200;
  const left =
    document.getElementById("makeTeamPostView").getBoundingClientRect().left +
    300;
  console.log(top, left);
  const option =
    "width=550, height=350, top=" +
    top +
    ", left=" +
    left +
    ", location=no, resizable=no";
  console.log(option);
  window.open(url, fname, option);
}
