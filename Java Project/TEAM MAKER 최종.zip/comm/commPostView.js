"use strict";

const toggleBtn = document.querySelector(".toggleBtn");
const uplog = document.querySelectorAll(".uplog");
const navbar_upper = document.querySelector(".navbar_upper");

toggleBtn.addEventListener("click", () => {
  console.log("토글 버튼 클릭");
  Array.from(uplog).forEach((element) => {
    element.classList.toggle("active");
  });
  navbar_upper.classList.toggle("active");
});

//신고하기
window.addEventListener("load", init);
function init() {
  let reportTag = document.querySelector("#report");

  reportTag.addEventListener("click", report_F);
}

function report_F(event) {
  event.preventDefault();
  console.log("report");
  const url = event.target.href;
  const fname = event.target.id;
  const top =
    document.getElementById("commPostView").getBoundingClientRect().top + 200;
  const left =
    document.getElementById("commPostView").getBoundingClientRect().left + 300;
  console.log(top, left);
  const option =
    "width=550, height=350, top=" +
    top +
    ", left=" +
    left +
    ", location=no, resizable=no";
  console.log(option);
  window.open(url, fname, option);
}
