// 답변 부분 화살표 클릭 시
const moreBtns = document.querySelectorAll(".moreBtn");
const answerPart = document.querySelectorAll(".answerPart");

Array.from(moreBtns).forEach((btn) => {
  btn.addEventListener("click", (e) => {
    console.log(
      e.target
        .closest(".questionList")
        .nextElementSibling.classList.toggle("active")
    );
  });
});
