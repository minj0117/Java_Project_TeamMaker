// 답변 부분 화살표 클릭 시
const moreBtns = document.querySelectorAll(".moreBtn");
const reasonPart = document.querySelectorAll(".reasonPart");

Array.from(moreBtns).forEach((btn) => {
  btn.addEventListener("click", (e) => {
    e.target
      .closest(".reportList")
      .nextElementSibling.classList.toggle("active");

    if (e.target.tagName == "BUTTON") {
      e.target.classList.toggle("clicked");
    } else if (e.target.tagName == "I") {
      e.target.parentElement.classList.toggle("clicked");
    }
  });
});
